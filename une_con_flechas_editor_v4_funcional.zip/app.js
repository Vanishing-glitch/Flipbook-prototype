const state={
  title:"Match the pictures to the correct product and usage",
  columns:[
    {id:uid(),title:"Pictures",type:"image"},
    {id:uid(),title:"Products",type:"text"},
    {id:uid(),title:"Definitions",type:"text"}
  ],
  relations:[
    {id:uid(),values:[
      {text:"Razor",image:""},
      {text:"Razor",image:""},
      {text:"You use it to remove hair from your face, arms, or legs.",image:""}
    ]},
    {id:uid(),values:[
      {text:"Perfume",image:""},
      {text:"Perfume",image:""},
      {text:"You spray it on your body to smell nice during the day.",image:""}
    ]},
    {id:uid(),values:[
      {text:"Lotion",image:""},
      {text:"Lotion",image:""},
      {text:"You put it on your skin. It helps when your skin is dry.",image:""}
    ]}
  ]
};

const editor=document.getElementById("editor");
let student={orders:[],connections:[],selected:null};

function uid(){return crypto.randomUUID()}
function esc(s){return String(s??"").replaceAll("&","&amp;").replaceAll('"',"&quot;").replaceAll("<","&lt;").replaceAll(">","&gt;")}
function colTypeOptions(type){return `<option value="text" ${type==="text"?"selected":""}>Solo texto</option><option value="image" ${type==="image"?"selected":""}>Solo imagen</option><option value="text-image" ${type==="text-image"?"selected":""}>Texto + imagen</option>`}

function renderEditor(){
  editor.innerHTML="";
  const head=document.createElement("div");
  head.className="grid-header";head.style.setProperty("--columns",state.columns.length);
  head.innerHTML=`<div class="header-cell"><small>#</small></div>`+
    state.columns.map((c,i)=>`<div class="header-cell">
      <strong>Columna ${i+1}</strong>
      <input value="${esc(c.title)}" data-col-title="${i}">
      <select class="type-select" data-col-type="${i}">${colTypeOptions(c.type)}</select>
      ${state.columns.length>2?`<button class="danger" data-remove-column="${i}" style="margin-top:7px">Eliminar columna</button>`:""}
    </div>`).join("");
  editor.appendChild(head);

  state.relations.forEach((rel,r)=>{
    const row=document.createElement("div");row.className="relation-row";row.style.setProperty("--columns",state.columns.length);
    let html=`<div class="row-number">${r+1}</div>`;
    state.columns.forEach((col,c)=>{
      const v=rel.values[c]||{text:"",image:""};
      html+=`<div class="cell">
        <div class="cell-tools"><span class="relation-badge">Relación ${r+1}</span><button class="danger remove-row" data-remove-row="${r}">✕</button></div>
        <textarea data-text="${r}:${c}" placeholder="${col.type==="image"?"Texto opcional":"Palabra o frase"}">${esc(v.text)}</textarea>
        <div class="image-box">
          <input type="file" accept="image/*" data-file="${r}:${c}">
          <input type="text" placeholder="URL de imagen (opcional)" value="${esc(v.image)}" data-url="${r}:${c}" style="margin-top:6px">
          ${v.image?`<img class="thumb" src="${esc(v.image)}"><button class="danger clear-image" data-clear="${r}:${c}">Quitar imagen</button>`:""}
        </div>
      </div>`;
    });
    row.innerHTML=html;editor.appendChild(row);
  });

  const foot=document.createElement("div");foot.className="footer-actions";foot.innerHTML='<button id="addRelationBottom">+ Agregar relación</button>';editor.appendChild(foot);
  bindEditorEvents();
}

function bindEditorEvents(){
  editor.querySelectorAll("[data-col-title]").forEach(x=>x.oninput=()=>state.columns[+x.dataset.colTitle].title=x.value);
  editor.querySelectorAll("[data-col-type]").forEach(x=>x.onchange=()=>{state.columns[+x.dataset.colType].type=x.value;renderEditor()});
  editor.querySelectorAll("[data-remove-column]").forEach(b=>b.onclick=()=>{if(state.columns.length<=2)return alert("Debe haber al menos 2 columnas.");const c=+b.dataset.removeColumn;state.columns.splice(c,1);state.relations.forEach(r=>r.values.splice(c,1));renderEditor()});
  editor.querySelectorAll("[data-remove-row]").forEach(b=>b.onclick=()=>{state.relations.splice(+b.dataset.removeRow,1);renderEditor()});
  editor.querySelectorAll("[data-text]").forEach(x=>x.oninput=()=>{const[r,c]=x.dataset.text.split(":").map(Number);state.relations[r].values[c].text=x.value});
  editor.querySelectorAll("[data-url]").forEach(x=>x.oninput=()=>{const[r,c]=x.dataset.url.split(":").map(Number);state.relations[r].values[c].image=x.value;renderEditor()});
  editor.querySelectorAll("[data-file]").forEach(x=>x.onchange=()=>{const f=x.files?.[0];if(!f)return;if(!f.type.startsWith("image/"))return alert("Selecciona una imagen.");const[r,c]=x.dataset.file.split(":").map(Number);const reader=new FileReader();reader.onload=()=>{state.relations[r].values[c].image=reader.result;renderEditor()};reader.readAsDataURL(f)});
  editor.querySelectorAll("[data-clear]").forEach(b=>b.onclick=()=>{const[r,c]=b.dataset.clear.split(":").map(Number);state.relations[r].values[c].image="";renderEditor()});
  document.getElementById("addRelationBottom").onclick=addRelation;
}
function addRelation(){state.relations.push({id:uid(),values:state.columns.map(()=>({text:"",image:""}))});renderEditor()}
function addColumn(){const index=state.columns.length+1;state.columns.push({id:uid(),title:`Columna ${index}`,type:"text"});state.relations.forEach(r=>r.values.push({text:"",image:""}));renderEditor()}
function shuffled(arr){return [...arr].sort(()=>Math.random()-.5)}

document.getElementById("titleInput").oninput=e=>state.title=e.target.value;
document.getElementById("addColumnBtn").onclick=addColumn;
document.getElementById("addRowBtn").onclick=addRelation;
document.getElementById("previewBtn").onclick=openStudent;
document.getElementById("shuffleBtn").onclick=openStudent;
document.getElementById("closeModal").onclick=()=>document.getElementById("modal").classList.add("hidden");
document.getElementById("studentShuffle").onclick=()=>{setupStudent();renderStudent()};
document.getElementById("checkStudent").onclick=checkStudent;

function setupStudent(){
  student.orders=state.columns.map(()=>shuffled(state.relations.map(r=>r.id)));
  student.connections=[];
  student.selected=null;
  document.getElementById("studentResult").textContent="";
}

function openStudent(){
  document.getElementById("modal").classList.remove("hidden");
  setupStudent();
  renderStudent();
}

function getRelation(id){return state.relations.find(r=>r.id===id)}
function getValueById(relId,col){const r=getRelation(relId);return r?.values[col]||{text:"",image:""}}

function renderStudent(){
  const target=document.getElementById("preview");
  target.innerHTML=`<div class="student-grid"></div>`;
  const grid=target.querySelector(".student-grid");
  grid.style.gridTemplateColumns=`repeat(${state.columns.length},250px)`;

  state.columns.forEach((col,c)=>{
    const box=document.createElement("div");box.className="student-column";
    const h=document.createElement("h3");h.textContent=col.title;box.appendChild(h);
    const items=document.createElement("div");items.className="student-items";
    student.orders[c].forEach((relId,pos)=>{
      const v=getValueById(relId,c);
      const item=document.createElement("div");
      item.className="student-item";
      item.dataset.column=c;item.dataset.pos=pos;item.dataset.rel=relId;
      const content=document.createElement("div");content.className="student-content";
      if(col.type!=="text"&&v.image){const img=document.createElement("img");img.src=v.image;img.alt=v.text;content.appendChild(img)}
      if(col.type!=="image"){const text=document.createElement("div");text.textContent=v.text;content.appendChild(text)}
      if(col.type==="image"&&!v.image)content.textContent="🖼️ Imagen";
      item.appendChild(content);
      item.onclick=()=>studentClick(c,pos,relId);
      items.appendChild(item);
    });
    box.appendChild(items);grid.appendChild(box);
  });

  drawStudentLines(grid);
}

function studentClick(c,pos,relId){
  if(!student.selected){
    student.selected={c,pos,relId};
    renderStudent();
    return;
  }

  if(student.selected.c===c){
    student.selected={c,pos,relId};
    renderStudent();
    return;
  }

  let from=student.selected,to={c,pos,relId};
  if(Math.abs(from.c-to.c)!==1){
    document.getElementById("studentResult").textContent="Selecciona un elemento de la columna siguiente o anterior.";
    return;
  }

  let a=from,b=to;
  if(a.c>b.c)[a,b]=[b,a];

  // One connection per item. Replace any old connection involving either endpoint.
  student.connections=student.connections.filter(x=>
    !(x.fromC===a.c&&x.fromPos===a.pos)&&
    !(x.toC===b.c&&x.toPos===b.pos)
  );

  student.connections.push({
    fromC:a.c,fromPos:a.pos,fromRel:a.relId,
    toC:b.c,toPos:b.pos,toRel:b.relId
  });

  student.selected=null;
  document.getElementById("studentResult").textContent="";
  renderStudent();
}

function drawStudentLines(grid){
  const old=grid.querySelector("svg.student-lines");old?.remove();
  const svg=document.createElementNS("http://www.w3.org/2000/svg","svg");
  svg.classList.add("student-lines");
  svg.setAttribute("width",grid.scrollWidth);
  svg.setAttribute("height",grid.scrollHeight);

  const defs=document.createElementNS("http://www.w3.org/2000/svg","defs");
  defs.innerHTML=`<marker id="studentArrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10 Z" fill="currentColor"/></marker>`;
  svg.appendChild(defs);

  student.connections.forEach((c,index)=>{
    const a=grid.querySelector(`.student-item[data-column="${c.fromC}"][data-pos="${c.fromPos}"]`);
    const b=grid.querySelector(`.student-item[data-column="${c.toC}"][data-pos="${c.toPos}"]`);
    if(!a||!b)return;
    const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect(),gr=grid.getBoundingClientRect();
    const x1=ar.right-gr.left,y1=ar.top+ar.height/2-gr.top;
    const x2=br.left-gr.left,y2=br.top+br.height/2-gr.top;
    const dx=Math.max(35,(x2-x1)*.45);
    const path=document.createElementNS("http://www.w3.org/2000/svg","path");
    path.classList.add("student-line");
    path.dataset.connection=index;
    path.style.color="var(--primary)";
    path.setAttribute("marker-end","url(#studentArrow)");
    path.setAttribute("d",`M${x1} ${y1} C${x1+dx} ${y1},${x2-dx} ${y2},${x2} ${y2}`);
    svg.appendChild(path);
  });
  grid.appendChild(svg);

  if(student.selected){
    const s=grid.querySelector(`.student-item[data-column="${student.selected.c}"][data-pos="${student.selected.pos}"]`);
    s?.classList.add("selected");
  }
}

function checkStudent(){
  let correct=0;
  student.connections.forEach(c=>{
    const good=c.fromRel===c.toRel;
    if(good)correct++;
    const a=document.querySelector(`#preview .student-item[data-column="${c.fromC}"][data-pos="${c.fromPos}"]`);
    const b=document.querySelector(`#preview .student-item[data-column="${c.toC}"][data-pos="${c.toPos}"]`);
    a?.classList.toggle("correct",good);a?.classList.toggle("incorrect",!good);
    b?.classList.toggle("correct",good);b?.classList.toggle("incorrect",!good);
  });

  const expected=state.relations.length*(state.columns.length-1);
  const complete=student.connections.length===expected;
  let text=`Resultado: ${correct} de ${student.connections.length} conexiones correctas.`;
  if(complete&&correct===expected)text+=" 🎉 ¡Ejercicio completado correctamente!";
  else if(!complete)text+=` Faltan ${expected-student.connections.length} conexiones.`;
  document.getElementById("studentResult").textContent=text;
}

renderEditor();
