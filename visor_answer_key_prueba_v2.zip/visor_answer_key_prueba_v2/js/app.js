const pages = [
 {n:1,title:"Portada",html:`<h1>Libro de prueba</h1><p>Visor independiente para probar la relación entre páginas, ejercicios y Answer Key.</p><div class="box"><b>Prueba de navegación:</b><p>Usá los botones o las teclas <b>←</b> y <b>→</b> para cambiar de página.</p></div>`},
 {n:2,title:"Vocabulary",html:`<h1>Vocabulary</h1><p>Contenido de ejemplo del libro.</p><div class="box"><span class="exercise-tag">Exercise 1</span><p>Match the words with their meanings.</p><p>book · sun · teacher · car</p></div>`},
 {n:3,title:"Write Answer",html:`<h1>Write the Answer</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>I ___ to school every day.</p><input placeholder="Type your answer"></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>The girl ___ lives next door is my friend.</p><input placeholder="Type your answer"></div>`},
 {n:4,title:"Write Answer",html:`<h1>Write the Answer</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>We ___ watching a movie yesterday.</p><input placeholder="Type your answer"></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>This is the place ___ I was born.</p><input placeholder="Type your answer"></div>`},
 {n:5,title:"Multiple Choice",html:`<h1>Multiple Choice</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>What is the capital of France?</p><select><option>Select...</option><option>Madrid</option><option>Paris</option><option>Rome</option></select></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>Which animal is a mammal?</p><select><option>Select...</option><option>Shark</option><option>Dolphin</option><option>Snake</option></select></div>`},
 {n:6,title:"True / False",html:`<h1>True / False</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>The Earth is a planet.</p><select><option>Select...</option><option>True</option><option>False</option></select></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>The sun is a planet.</p><select><option>Select...</option><option>True</option><option>False</option></select></div>`},
 {n:7,title:"Multiple Choice",html:`<h1>Multiple Choice</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Which word is a verb?</p><select><option>Select...</option><option>Beautiful</option><option>Run</option><option>Quickly</option></select></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>Choose the correct past tense.</p><select><option>Select...</option><option>go</option><option>went</option><option>going</option></select></div>`},
 {n:8,title:"Image & Answer",html:`<h1>Image and Answer</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>🦁 Look at the image and write the animal.</p><input placeholder="Your answer"></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>✈️ Identify the object.</p><input placeholder="Your answer"></div>`},
 {n:9,title:"Image & Answer",html:`<h1>Image and Answer</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>🏫 What place is represented?</p><input placeholder="Your answer"></div>`},
 {n:10,title:"Matching",html:`<h1>Unir con flechas</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Connect each item with its definition.</p><p>1. Sun → Gives light and heat<br>2. Book → I read it<br>3. Car → Transportation</p></div>`},
 {n:11,title:"Matching",html:`<h1>Unir con flechas</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Match the professions with their descriptions.</p><p>1. Doctor<br>2. Teacher<br>3. Pilot</p></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>Match the countries with capitals.</p></div>`},
 {n:12,title:"Matrix",html:`<h1>Matrix</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Complete the missing cells.</p><p>Information | Landmark | Country</p><p>Roman site | ___ | Italy</p><p>___ | Great Wall of China | China</p></div>`},
 {n:13,title:"Matrix",html:`<h1>Matrix</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Complete the table.</p><p>Animal | Habitat | Food</p><p>Lion | ___ | Meat</p><p>___ | Ocean | Fish</p></div>`},
 {n:14,title:"Multiple Choice + Justification",html:`<h1>Selection + Justification</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>Which sentence is correct?</p><select><option>Select...</option><option>She go to school.</option><option>She goes to school.</option></select><p>Justification: ____________________</p></div>`},
 {n:15,title:"Write Answer + Alternatives",html:`<h1>Write Answer</h1><div class="box"><span class="exercise-tag">Exercise 1</span><p>The person ___ called me was John.</p><input placeholder="who / that"></div><div class="box"><span class="exercise-tag">Exercise 2</span><p>I have ___ finished my homework.</p><input placeholder="already / just"></div>`},
 {n:16,title:"Mixed Exercises",html:`<h1>Mixed Exercises</h1><div class="box"><span class="exercise-tag">Exercise 1 — Multiple Choice</span><p>Choose the correct option.</p><select><option>Select...</option><option>A</option><option>B</option><option>C</option></select></div><div class="box"><span class="exercise-tag">Exercise 2 — Write Answer</span><p>Complete: They ___ happy.</p><input placeholder="answer"></div>`},
 {n:17,title:"Mixed Exercises",html:`<h1>Mixed Exercises</h1><div class="box"><span class="exercise-tag">Exercise 1 — Image</span><p>🐶 Identify the animal.</p><input placeholder="answer"></div><div class="box"><span class="exercise-tag">Exercise 2 — True / False</span><p>Dogs are mammals.</p><select><option>Select...</option><option>True</option><option>False</option></select></div>`},
 {n:18,title:"Matching + Matrix",html:`<h1>Matching + Matrix</h1><div class="box"><span class="exercise-tag">Exercise 1 — Matching</span><p>Match each item with the correct option.</p></div><div class="box"><span class="exercise-tag">Exercise 2 — Matrix</span><p>Complete the missing information.</p></div>`},
 {n:19,title:"Review",html:`<h1>Review</h1><p>Última sección de ejercicios de prueba.</p><div class="box"><span class="exercise-tag">Exercise 1</span><p>Mixed activity with several answer fields.</p></div>`},
 {n:20,title:"Final",html:`<h1>Final</h1><p>Fin del libro de prueba.</p><div class="box"><b>Probamos:</b><p>Write Answer · Multiple Choice · True/False · Image & Answer · Matching · Matrix · Justification</p></div>`}
];

const exercises = {
  3:[
   {title:"Exercise 1 — Write Answer",answers:["go"]},
   {title:"Exercise 2 — Write Answer",answers:["who","that"]}
  ],
  4:[
   {title:"Exercise 1 — Write Answer",answers:["were"]},
   {title:"Exercise 2 — Write Answer",answers:["where"]}
  ],
  5:[
   {title:"Exercise 1 — Multiple Choice",answers:["Paris"]},
   {title:"Exercise 2 — Multiple Choice",answers:["Dolphin"]}
  ],
  6:[
   {title:"Exercise 1 — True / False",answers:["True"]},
   {title:"Exercise 2 — True / False",answers:["False"]}
  ],
  7:[
   {title:"Exercise 1 — Multiple Choice",answers:["Run"]},
   {title:"Exercise 2 — Multiple Choice",answers:["went"]}
  ],
  8:[
   {title:"Exercise 1 — Image & Answer",answers:["Lion"]},
   {title:"Exercise 2 — Image & Answer",answers:["Airplane","Aeroplane"]}
  ],
  9:[
   {title:"Exercise 1 — Image & Answer",answers:["School"]}
  ],
  10:[
   {title:"Exercise 1 — Matching",answers:["1 → A","2 → B","3 → C"]}
  ],
  11:[
   {title:"Exercise 1 — Matching",answers:["1 → B","2 → C","3 → A"]},
   {title:"Exercise 2 — Matching",answers:["Brazil → Brasília","France → Paris","Japan → Tokyo"]}
  ],
  12:[
   {title:"Exercise 1 — Matrix",answers:["Colosseum","A Roman site / Great Wall of China"]}
  ],
  13:[
   {title:"Exercise 1 — Matrix",answers:["Savanna","Shark"]}
  ],
  14:[
   {title:"Exercise 1 — Multiple Choice + Justification",answers:["She goes to school."]}
  ],
  15:[
   {title:"Exercise 1 — Write Answer",answers:["who","that"]},
   {title:"Exercise 2 — Write Answer",answers:["already","just"]}
  ],
  16:[
   {title:"Exercise 1 — Multiple Choice",answers:["B"]},
   {title:"Exercise 2 — Write Answer",answers:["are"]}
  ],
  17:[
   {title:"Exercise 1 — Image & Answer",answers:["Dog"]},
   {title:"Exercise 2 — True / False",answers:["True"]}
  ],
  18:[
   {title:"Exercise 1 — Matching",answers:["1 → C","2 → A","3 → B"]},
   {title:"Exercise 2 — Matrix",answers:["Lion / Savanna","Shark / Ocean"]}
  ],
  19:[
   {title:"Exercise 1 — Mixed",answers:["go","Paris","True"]}
  ]
};

let current=1;
const pageEl=document.getElementById("page");
function render(){
  const p=pages[current-1];
  pageEl.innerHTML=p.html;
  document.getElementById("pageNo").textContent=`P/${pages.length}`;
  document.title=p.title+" — Visor";
  window.scrollTo(0,0);
}
function go(n){current=Math.max(1,Math.min(pages.length,n));render()}
document.getElementById("prev").onclick=()=>go(current-1);
document.getElementById("next").onclick=()=>go(current+1);

document.addEventListener("keydown",e=>{
  const tag=(e.target.tagName||"").toLowerCase();
  const modalOpen=!document.getElementById("modal").classList.contains("hidden");
  if(modalOpen) return;
  if(tag==="input"||tag==="textarea"||tag==="select") return;
  if(e.key==="ArrowLeft"){e.preventDefault();go(current-1)}
  if(e.key==="ArrowRight"){e.preventDefault();go(current+1)}
});

const modal=document.getElementById("modal"),sel=document.getElementById("pages"),list=document.getElementById("exerciseList"),answers=document.getElementById("answers");
function loadPages(){
  sel.innerHTML=pages.map(p=>`<option value="${p.n}">Página ${p.n}${exercises[p.n]?` — ${exercises[p.n].length} ejercicio(s)`:``}</option>`).join("");
  sel.value=current;
}
function loadExercises(n){
  answers.classList.add("hidden");answers.innerHTML="";
  const data=exercises[n]||[];
  list.innerHTML=data.length?data.map((e,i)=>`<button class="exercise" data-i="${i}">${i+1}. ${e.title}</button>`).join(""):"<p class='muted'>No hay ejercicios cargados en esta página.</p>";
  list.querySelectorAll(".exercise").forEach(b=>b.onclick=()=>showAnswer(data[Number(b.dataset.i)],b));
}
function showAnswer(e,b){
  list.querySelectorAll(".exercise").forEach(x=>x.classList.remove("active"));
  b.classList.add("active");
  answers.classList.remove("hidden");
  answers.innerHTML=`<h3>Respuestas correctas</h3>${e.answers.map((a,i)=>`<div class="ans">${i+1}. <span class="value">${a}</span></div>`).join("")}<div class="answer-note">Las respuestas se cargan desde la configuración del ejercicio.</div>`;
}
document.getElementById("key").onclick=()=>{modal.classList.remove("hidden");loadPages();loadExercises(current)};
document.getElementById("close").onclick=()=>modal.classList.add("hidden");
sel.onchange=()=>loadExercises(Number(sel.value));
modal.onclick=e=>{if(e.target===modal)modal.classList.add("hidden")};
render();
