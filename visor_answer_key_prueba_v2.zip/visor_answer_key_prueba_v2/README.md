# Visor de prueba — Answer Key v2

Versión ampliada para probar la futura integración con el flipbook real.

Incluye:
- 20 páginas.
- Navegación con botones.
- Navegación con las teclas ← y → del teclado.
- La navegación por teclado se desactiva mientras el Answer Key está abierto y mientras se escribe en un campo/select.
- Más ejercicios y variaciones:
  - Write Answer
  - Multiple Choice
  - True / False
  - Image & Answer
  - Matching / Unir con flechas
  - Matrix
  - Multiple Choice + Justification
  - Ejercicios mixtos
  - Múltiples respuestas aceptadas
- Answer Key:
  1. Elegís la página.
  2. El sistema muestra los ejercicios existentes en esa página.
  3. Elegís el ejercicio.
  4. Se muestran automáticamente las respuestas configuradas.

## Ejecutar

No requiere Node ni servidor.

1. Extraer el ZIP.
2. Abrir `index.html`.
3. Probar las flechas del teclado.
4. Abrir `🔑 Answer Key`.

## Próximo paso

La estructura de `pages` y `exercises` está separada para que luego podamos reemplazar los datos de prueba por la estructura real del flipbook.
